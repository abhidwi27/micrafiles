import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ClaimSetUpViewerData } from './ClaimSetUpViewerData';
import { catchError, map, tap } from 'rxjs/operators';
import { Observable , of } from 'rxjs'

@Injectable({
  providedIn: 'root'
})
export class ClaimsetupviewerService {

  public data: Observable<ClaimSetUpViewerData[]>;

  private _url: string = '../assets/data/claimSetupViewer.json';

  constructor(private http: HttpClient) { }

  getClaimSetupViewerData(): Observable<ClaimSetUpViewerData[]>{
    this.data =  this.http.get<ClaimSetUpViewerData[]>(this._url);
    console.log("Data in service is " + this.data );    
    return this.http.get<ClaimSetUpViewerData[]>(this._url)
      .pipe(
        tap(claimSetupViewerData => {          
          console.log("ClaimSetupViewerData Fetched");          
        }),
        catchError(this.handleError('getClaimSetupViewerData', []))
      );
  }

  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      console.error(error); 
      console.log(`${operation} failed: ${error.message}`);
      return of(result as T);
    };
  }
}
