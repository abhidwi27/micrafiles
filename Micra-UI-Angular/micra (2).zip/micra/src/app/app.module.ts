import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { AppRoutingModule} from './/app-routing.module';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { ModalModule } from 'ngx-bootstrap/modal';
//import { DataTableModules } from 'angular-datatables';

import { library } from '@fortawesome/fontawesome-svg-core';
import { fas, faSort } from '@fortawesome/free-solid-svg-icons';
import { far } from '@fortawesome/free-regular-svg-icons';
import { faBars } from '@fortawesome/free-solid-svg-icons';
import { faArrowAltCircleUp } from '@fortawesome/free-solid-svg-icons';
import { faArrowAltCircleLeft } from '@fortawesome/free-solid-svg-icons';
import { faPrint } from '@fortawesome/free-solid-svg-icons';
import { faList } from '@fortawesome/free-solid-svg-icons';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { TopnavComponent } from './topnav/topnav.component';
import { WorknolComponent } from './worknol/worknol.component';
import { WorknolnoticeComponent } from './worknolnotice/worknolnotice.component';
import { WorknolcedeComponent } from './worknolcede/worknolcede.component';
import { WyqComponent } from './wyq/wyq.component';
import { ClaimsetupComponent } from './claimsetup/claimsetup.component';
import { WorknoltypeComponent } from './worknoltype/worknoltype.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { importExpr } from '@angular/compiler/src/output/output_ast';
import { WyqService } from './wyq.service';
import { HttpClientModule } from '@angular/common/http';



library.add(fas, far);
library.add(faBars);
library.add(faArrowAltCircleUp);
library.add(faArrowAltCircleLeft);
library.add(faSort);
library.add(faPrint);
library.add(faList);

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    TopnavComponent,
    WorknolComponent,
    WorknolnoticeComponent,
    WorknolcedeComponent,
    WyqComponent,
    ClaimsetupComponent,
    WorknoltypeComponent,
    HeaderComponent,
    FooterComponent
  ],
  imports: [
    BrowserModule,
    FontAwesomeModule,
    AppRoutingModule,
    BsDropdownModule.forRoot(),
    TooltipModule.forRoot(),
    ModalModule.forRoot(),
    HttpClientModule
    //DataTablesModule
  ],
  providers: [WyqService],
  bootstrap: [AppComponent]
})
export class AppModule { }
