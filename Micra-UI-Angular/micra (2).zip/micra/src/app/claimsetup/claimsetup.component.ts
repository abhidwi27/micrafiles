import { Component, OnInit, Renderer2 } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { ClaimsetupviewerService } from '../claimsetupviewer.service';
import { ClaimSetUpViewerData } from '../ClaimSetUpViewerData';
import { Router } from '@angular/router';
declare var $: any;

@Component({
  selector: 'app-claimsetup',
  templateUrl: './claimsetup.component.html',
  styleUrls: ['./claimsetup.component.css']
})
export class ClaimsetupComponent implements OnInit {

  policy: string;
  claim: string;
  private sub: any;
  public claimSetUpViewerDataList = [];
  public claimSetUpViewerData: ClaimSetUpViewerData;
  public workNolModelVisible: boolean;
  public noticeOfWork = new Map();

  

  constructor(private renderer: Renderer2,
     private location: Location, 
     private route: ActivatedRoute,
     private router: Router,
     private _claimSetUpViewerSvc: ClaimsetupviewerService ) { }

  ngOnInit() {
    this.renderer.removeAttribute(document.body, 'class');
    this.renderer.addClass(document.body, 'claimsetup-content');

    this.sub = this.route.params.subscribe(params => {
      this.policy = params['policy'];
      this.claim = params['claim'];    
    });
      console.log("policy is " + this.policy);
      console.log("claim is " + this.claim);

      this._claimSetUpViewerSvc.getClaimSetupViewerData()
      .subscribe( data => {
         this.claimSetUpViewerDataList = data;
         
         this.claimSetUpViewerData = this.claimSetUpViewerDataList[0];

          
          let countOfNw = 0;
          this.noticeOfWork.set("reNw",parseInt(this.claimSetUpViewerData["reNw"], 10) > 0);
          this.noticeOfWork.set("paNw",parseInt(this.claimSetUpViewerData["paNw"], 10) > 0);
          this.noticeOfWork.set("exNw",parseInt(this.claimSetUpViewerData["exNw"], 10) > 0);
          this.noticeOfWork.set("saNw",parseInt(this.claimSetUpViewerData["saNw"], 10) > 0);
          this.noticeOfWork.set("suNw",parseInt(this.claimSetUpViewerData["suNw"], 10) > 0);

          this.noticeOfWork.forEach((value: boolean, key: string) => {
            if(value){
                countOfNw ++;
            }

            if(countOfNw > 1){
              this.workNolModelVisible = true;
            }else{
              this.workNolModelVisible = false;
            }
        });

        })

        
    
  };

  getBack() {
    this.location.back();
  }

  workeNolClickHandler(){
    if(this.workNolModelVisible){
      $("#workNOLModal").modal('show');
    }else{
      this.router.navigate(['/worknol']);
    }
  }

}
