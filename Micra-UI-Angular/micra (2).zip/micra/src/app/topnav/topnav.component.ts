import { Component, OnInit, Renderer2 } from '@angular/core';

@Component({
  selector: 'app-topnav',
  templateUrl: './topnav.component.html',
  styleUrls: ['./topnav.component.css']
})
export class TopnavComponent implements OnInit {

  constructor(private renderer: Renderer2) { }

  ngOnInit() {
  }


  toggleNav(ref, className: string){
   
    const hasClass = ref.classList.contains(className);

    if(hasClass) {
      this.renderer.removeClass(ref, className);
    } 
    
  }
}
