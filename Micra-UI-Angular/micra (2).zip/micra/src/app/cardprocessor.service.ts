import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CardProcessorData } from './CardProcessorData';
import { catchError, map, tap } from 'rxjs/operators';
import { Observable , of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CardprocessorService {

  public data: Observable<CardProcessorData[]>;
  private _url: string = '../assets/data/cardProcessor.json';


  constructor(private http: HttpClient) { }
  
  getCardProcessorData(): Observable<CardProcessorData[]>{
    this.data =  this.http.get<CardProcessorData[]>(this._url);
    console.log("Data in service is " + this.data );    
    return this.http.get<CardProcessorData[]>(this._url)
      .pipe(
        tap(claimSetupViewerData => {          
          console.log("CardProcessor Data Fetched");          
        }),
        catchError(this.handleError('getCardProcessorData', []))
      );
  }

  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      console.error(error); 
      console.log(`${operation} failed: ${error.message}`);
      return of(result as T);
    };
  }
}
