export interface AmountToCedeData{
    policyNumber: string,
    claimNumber: string,
    layerId: string,
    layerName: string,
    attach: string,
    limit: string,
    directAmountapplied: string
}