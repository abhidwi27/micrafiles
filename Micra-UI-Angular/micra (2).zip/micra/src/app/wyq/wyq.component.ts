import { Component, OnInit, Renderer2, QueryList, ViewChildren } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import * as $ from 'jquery';
import 'datatables.net';
import 'datatables.net-bs4';
import { WyqService } from '../wyq.service';


@Component({
  selector: 'app-wyq',
  templateUrl: './wyq.component.html',
  styleUrls: ['./wyq.component.css']
})
export class WyqComponent implements OnInit {
  dataTable: any;
  dtOptions: any = {};
  public claimDataArray = [];
  public largeAmountclaims=0;
  public otherClaims=0;
  public suspendedClaims=0;
  public claimsTobeworked=0;

  @ViewChildren('wyqData') things: QueryList<any>;

  constructor(
    private renderer: Renderer2, 
    private router: Router,
    private location: Location,
    private _wyqSvc: WyqService) { 
    
  }

  ngOnInit() {
    this.renderer.removeAttribute(document.body, 'class');
    this.renderer.addClass(document.body, 'wyq-content');

    this.dtOptions = {
      dom: 'Bfrtip',
      // Configure the buttons
      buttons: [
        'copy',
        'print',
        'csv',
        'excel',
        'pdf'
      ]
    }

    

     this._wyqSvc.getWyqDataByUserId()
        .subscribe(data => {this.claimDataArray = data
          this.claimsTobeworked = this.claimDataArray.length
          for(let claim in this.claimDataArray ){
              if(this.claimDataArray[claim]["quLargeLossIndicator"]=="Y"){
                this.largeAmountclaims++;
                
              }
    
              if(this.claimDataArray[claim]["quSuspensionReason"].length!=0){
                this.suspendedClaims++;
              }
          }
    
          this.otherClaims = this.claimsTobeworked - this.largeAmountclaims - this.suspendedClaims;
          console.log(this.otherClaims);})   
      
   }

  getClaimDetail(event, policy: string, claim: string){
    console.log("policy is " + policy)
    console.log("claim is " + claim);
    //this.router.navigate(['./', { outlets: { 'claimsetup-outlet': ['claimsetup', policy, claim]} }] );
    this.router.navigate(['/claimsetup', policy, claim] );
  }

  getBack() {
    this.location.back();
  }

  // ngAfterViewChecked(){
  //   this.claimsTobeworked = this.claimDataArray.length
  //       for(let claim in this.claimDataArray ){
  //           if(this.claimDataArray[claim]["quLargeLossIndicator"]=="Y"){
  //             this.largeAmountclaims++;
              
  //           }
  
  //           if(this.claimDataArray[claim]["quSuspensionReason"].length!=0){
  //             this.suspendedClaims++;
  //           }
  //       }
  
  //       this.otherClaims = this.claimsTobeworked - this.largeAmountclaims - this.suspendedClaims;
  //       console.log(this.otherClaims);
  // }
  ngAfterViewInit() {
    this.things.changes.subscribe(t => {
      
      this.ngForRendred();
    })

    
  }

  
  ngForRendred(){
    const table: any = $('#wyq-data');
    this.dataTable = table.dataTable();

  }

  
}
