import { Component, OnInit } from '@angular/core';
import { AmounttocedeService } from '../amounttocede.service';

@Component({
  selector: 'app-worknolcede',
  templateUrl: './worknolcede.component.html',
  styleUrls: ['./worknolcede.component.css']
})
export class WorknolcedeComponent implements OnInit {
  public amountToCedeDataList = [];
  constructor(private amountToCedeService: AmounttocedeService) { }

  ngOnInit() {
    this.amountToCedeService.getAmountToCedeData()
    .subscribe(data=> this.amountToCedeDataList = data);
  }

}
