import { Component, OnInit, Renderer2 } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private renderer: Renderer2, private router: Router, route:ActivatedRoute) {
  
   }

  ngOnInit() {
     this.renderer.removeAttribute(document.body, 'class');
     this.renderer.addClass(document.body, 'micra-home-background');
  }

  

}
