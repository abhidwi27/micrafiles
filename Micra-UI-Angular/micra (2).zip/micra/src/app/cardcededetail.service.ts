import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CardCedeDetailData } from './CardCedeDetailData';
import { catchError, map, tap } from 'rxjs/operators';
import { Observable , of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CardcededetailService {
  
  public data: Observable<CardCedeDetailData[]>;
  private _url: string = '../assets/data/cardCedeDetail.json';


  constructor(private http: HttpClient) { }

  getCardCedeDetailData(): Observable<CardCedeDetailData[]>{
    this.data =  this.http.get<CardCedeDetailData[]>(this._url);
    console.log("Data in service is " + this.data );    
    return this.http.get<CardCedeDetailData[]>(this._url)
      .pipe(
        tap(claimSetupViewerData => {          
          console.log("CardCedeDetail Data Fetched");          
        }),
        catchError(this.handleError('getCardCedeDetailData', []))
      );
  }


  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      console.error(error); 
      console.log(`${operation} failed: ${error.message}`);
      return of(result as T);
    };
  }
}
