import { TestBed, inject } from '@angular/core/testing';

import { CardprocessorService } from './cardprocessor.service';

describe('CardprocessorService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CardprocessorService]
    });
  });

  it('should be created', inject([CardprocessorService], (service: CardprocessorService) => {
    expect(service).toBeTruthy();
  }));
});
