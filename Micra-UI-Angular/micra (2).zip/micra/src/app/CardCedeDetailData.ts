export interface CardCedeDetailData{
        policyNumber: string,
        claimNumber: string,
        cardNumber: string,
        action: string,
        rac: string,
        percent: string,
        ceded: string,
        layerName: string
}