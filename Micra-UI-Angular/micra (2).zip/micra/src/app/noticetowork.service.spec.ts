import { TestBed, inject } from '@angular/core/testing';
import { HttpClient } from '@angular/common/http';
import { ClaimData } from './ClaimData';
import { catchError, map, tap } from 'rxjs/operators';
import { Observable , of } from 'rxjs';

import { NoticetoworkService } from './noticetowork.service';

describe('NoticetoworkService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [NoticetoworkService]
    });
  });

  it('should be created', inject([NoticetoworkService], (service: NoticetoworkService) => {
    expect(service).toBeTruthy();
  }));
});
