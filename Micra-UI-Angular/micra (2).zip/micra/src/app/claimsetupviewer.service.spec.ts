import { TestBed, inject } from '@angular/core/testing';

import { ClaimsetupviewerService } from './claimsetupviewer.service';

describe('ClaimsetupviewerService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ClaimsetupviewerService]
    });
  });

  it('should be created', inject([ClaimsetupviewerService], (service: ClaimsetupviewerService) => {
    expect(service).toBeTruthy();
  }));
});
