import { Component, OnInit, Renderer2 } from '@angular/core';
import { Location } from '@angular/common';
import { CardprocessorService } from '../cardprocessor.service';
import { CardcededetailService } from '../cardcededetail.service';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { CardProcessorData } from '../CardProcessorData';
import { CardCedeDetailData } from '../CardCedeDetailData';

@Component({
  selector: 'app-worknol',
  templateUrl: './worknol.component.html',
  styleUrls: ['./worknol.component.css']
})
export class WorknolComponent implements OnInit {

  public cardProcessorDataList = [];
  public cardProcessorData: CardProcessorData;
  public cardCedeDetailDataList = [];
  public cardCedeDetailData: CardCedeDetailData;
  
  


  constructor(private renderer: Renderer2, 
    private location: Location,
    private route: ActivatedRoute,
    private router: Router,
    private cardProcessorService: CardprocessorService,
    private cardCedeDetailService: CardcededetailService) { 
   
  }

  ngOnInit() {
    this.renderer.removeAttribute(document.body, 'class');
    this.renderer.addClass(document.body, 'work-nol-content');

    this.cardProcessorService.getCardProcessorData()
    .subscribe(
      data=>{ this.cardProcessorDataList = data;
      this.cardProcessorData = this.cardProcessorDataList[0];
      }
    )

    this.cardCedeDetailService.getCardCedeDetailData()
    .subscribe(
      data=>{ this.cardCedeDetailDataList = data;
      //this.cardProcessorData = this.cardProcessorDataList[0];
      }
    )
  }

  getBack() {
    this.location.back();
  }
  
}
