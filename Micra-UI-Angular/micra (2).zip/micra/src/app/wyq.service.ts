import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ClaimData } from './ClaimData';
import { catchError, map, tap } from 'rxjs/operators';
import { Observable , of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class WyqService {

  public data: Observable<ClaimData[]>;

  private _url: string = '../assets/data/wyqSample.json';

  constructor( private http: HttpClient ) { }

  getWyqDataByUserId(): Observable<ClaimData[]>{
    this.data =  this.http.get<ClaimData[]>(this._url);
    console.log("Data in service is " + this.data );    
    return this.http.get<ClaimData[]>(this._url)
      .pipe(
        tap(claimdata => {          
          console.log("Claim Data Fetched");          
        }),
        catchError(this.handleError('getWyqDataByUserId', []))
      );
  }

  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      console.error(error); 
      console.log(`${operation} failed: ${error.message}`);
      return of(result as T);
    };
  }
}

