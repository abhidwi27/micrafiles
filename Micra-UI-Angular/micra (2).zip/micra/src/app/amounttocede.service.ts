import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AmountToCedeData } from './AmountToCedeData';
import { catchError, map, tap } from 'rxjs/operators';
import { Observable , of } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class AmounttocedeService {

  public data: Observable<AmountToCedeData[]>;
  private _url: string = '../assets/data/amountToCede.json';

  constructor(private http: HttpClient) { }

  getAmountToCedeData(): Observable<AmountToCedeData[]>{
    this.data =  this.http.get<AmountToCedeData[]>(this._url);
    console.log("Data in service is " + this.data );    
    return this.http.get<AmountToCedeData[]>(this._url)
      .pipe(
        tap(claimSetupViewerData => {          
          console.log("AmountToCedeData Fetched");          
        }),
        catchError(this.handleError('getAmountToCedeData', []))
      );
  }

  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      console.error(error); 
      console.log(`${operation} failed: ${error.message}`);
      return of(result as T);
    };
  }
}
