import { TestBed, inject } from '@angular/core/testing';

import { CardcededetailService } from './cardcededetail.service';

describe('CardcededetailService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CardcededetailService]
    });
  });

  it('should be created', inject([CardcededetailService], (service: CardcededetailService) => {
    expect(service).toBeTruthy();
  }));
});
