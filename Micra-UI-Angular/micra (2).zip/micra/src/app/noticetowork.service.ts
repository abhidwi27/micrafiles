import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { NoticeToWorkData } from './NoticeToWorkData';
import { catchError, map, tap } from 'rxjs/operators';
import { Observable , of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class NoticetoworkService {

  public data: Observable<NoticeToWorkData[]>;
  private _url: string = '../assets/data/noticeToWork.json';

  constructor(private http: HttpClient) { }

  getNoticetowork(): Observable<NoticeToWorkData[]>{
    this.data =  this.http.get<NoticeToWorkData[]>(this._url);
    console.log("Data in service is " + this.data );    
    return this.http.get<NoticeToWorkData[]>(this._url)
      .pipe(
        tap(noticeToWorkData => {          
          console.log("NoticeToWork Data Fetched");          
        }),
        catchError(this.handleError('getNoticeToWorkData', []))
      );
  }

  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      console.error(error); 
      console.log(`${operation} failed: ${error.message}`);
      return of(result as T);
    };
  }
}
