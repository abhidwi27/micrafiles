import { Component, OnInit } from '@angular/core';
import { NoticetoworkService } from '../noticetowork.service';

@Component({
  selector: 'app-worknolnotice',
  templateUrl: './worknolnotice.component.html',
  styleUrls: ['./worknolnotice.component.css']
})
export class WorknolnoticeComponent implements OnInit {

  public noticeToWorkList = [];
  constructor(private noticeToWorkService: NoticetoworkService) { }

  ngOnInit() {
    this.noticeToWorkService.getNoticetowork()
    .subscribe(data=>{
      this.noticeToWorkList = data;
    })
  }

}
