import { Component, OnInit, Input, OnChanges, SimpleChange  } from '@angular/core';
import { Router } from '@angular/router';
import { ClaimsetupviewerService } from '../claimsetupviewer.service';
import { debug } from 'util';
import { ClaimSetUpViewerData } from '../ClaimSetUpViewerData';

@Component({
  selector: 'app-worknoltype',
  templateUrl: './worknoltype.component.html',
  styleUrls: ['./worknoltype.component.css']
})
export class WorknoltypeComponent implements OnInit {

  public reNwShow: boolean;
  public claimSetUpViewerData: ClaimSetUpViewerData;
  public claimSetUpViewerDataList = [];
  public reNwRadioDisabled;
  public paNwRadioDisabled;
  public exNwRadioDisabled;
  public saNwRadioDisabled;
  public suNwRadioDisabled;

  constructor(private router: Router, private _claimSetUpViewerSvc: ClaimsetupviewerService) { }

  ngOnInit() {
    this._claimSetUpViewerSvc.getClaimSetupViewerData()
      .subscribe( data => {
         this.claimSetUpViewerDataList = data;
         
         this.claimSetUpViewerData = this.claimSetUpViewerDataList[0];

          
          
          this.reNwRadioDisabled = parseInt(this.claimSetUpViewerData["reNw"], 10) == 0;
          this.paNwRadioDisabled = parseInt(this.claimSetUpViewerData["paNw"], 10) == 0;
          this.exNwRadioDisabled = parseInt(this.claimSetUpViewerData["exNw"], 10) == 0;
          this.saNwRadioDisabled = parseInt(this.claimSetUpViewerData["saNw"], 10) == 0;
          this.suNwRadioDisabled = parseInt(this.claimSetUpViewerData["suNw"], 10) == 0;

          console.log("reNwRadioDisabled is " + this.reNwRadioDisabled);
          console.log("paNwRadioDisabled is " + this.paNwRadioDisabled);


    })
}

getWorkNol(){
    this.router.navigate(['/worknol']);
  }

  
}
