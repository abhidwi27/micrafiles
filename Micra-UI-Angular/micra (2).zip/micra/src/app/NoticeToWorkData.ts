export interface NoticeToWorkData{
    policyNumber: string,
    claimNumber: string,
    rejectId: string,
    cardsNo: string,
    transaction: string,
    suffixNo: string
}