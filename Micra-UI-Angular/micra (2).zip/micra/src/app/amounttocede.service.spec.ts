import { TestBed, inject } from '@angular/core/testing';

import { AmounttocedeService } from './amounttocede.service';

describe('AmounttocedeService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AmounttocedeService]
    });
  });

  it('should be created', inject([AmounttocedeService], (service: AmounttocedeService) => {
    expect(service).toBeTruthy();
  }));
});
