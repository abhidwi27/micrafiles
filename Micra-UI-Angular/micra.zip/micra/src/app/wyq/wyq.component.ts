import { Component, OnInit, Renderer2, QueryList, ViewChildren } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import * as $ from 'jquery';
import 'datatables.net';
import 'datatables.net-bs4';
import { WyqService } from '../wyq.service';


@Component({
  selector: 'app-wyq',
  templateUrl: './wyq.component.html',
  styleUrls: ['./wyq.component.css']
})
export class WyqComponent implements OnInit {
  dataTable: any;
  dtOptions: any = {};
  public claimDataArray = [];

  @ViewChildren('wyqData') things: QueryList<any>;

  constructor(
    private renderer: Renderer2, 
    private router: Router,
    private location: Location,
    private _wyqSvc: WyqService) { 
    
  }

  ngOnInit() {
    this.renderer.removeAttribute(document.body, 'class');
    this.renderer.addClass(document.body, 'wyq-content');

    this.dtOptions = {
      dom: 'Bfrtip',
      // Configure the buttons
      buttons: [
        'copy',
        'print',
        'csv',
        'excel',
        'pdf'
      ]
    }

    

     this._wyqSvc.getWyqDataByUserId()
        .subscribe(data => this.claimDataArray = data); 
        
   }

  getClaimDetail(event, userid: string){
    console.log("user id is " + userid)
    this.router.navigate(['/claimsetup']);
  }

  getBack() {
    this.location.back();
  }

  ngAfterViewInit() {
    this.things.changes.subscribe(t => {
      this.ngForRendred();
    })
  }

  
  ngForRendred(){
    const table: any = $('#wyq-data');
    this.dataTable = table.dataTable();
  }
}
