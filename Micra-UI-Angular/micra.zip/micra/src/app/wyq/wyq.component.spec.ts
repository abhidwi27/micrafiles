import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WyqComponent } from './wyq.component';

describe('WyqComponent', () => {
  let component: WyqComponent;
  let fixture: ComponentFixture<WyqComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WyqComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WyqComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
