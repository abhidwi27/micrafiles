import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WorknolcedeComponent } from './worknolcede.component';

describe('WorknolcedeComponent', () => {
  let component: WorknolcedeComponent;
  let fixture: ComponentFixture<WorknolcedeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WorknolcedeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WorknolcedeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
