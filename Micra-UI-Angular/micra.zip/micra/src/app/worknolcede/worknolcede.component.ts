import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-worknolcede',
  templateUrl: './worknolcede.component.html',
  styleUrls: ['./worknolcede.component.css']
})
export class WorknolcedeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
