import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent} from './home/home.component';
import { WyqComponent } from './wyq/wyq.component';
import { WorknolComponent } from './worknol/worknol.component';
import { ClaimsetupComponent } from './claimsetup/claimsetup.component';

const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'wyq', component: WyqComponent },
  { path: 'worknol', component: WorknolComponent },
  { path: 'claimsetup', component: ClaimsetupComponent },
]

@NgModule({
  imports: [
    CommonModule,    
    RouterModule.forRoot(routes)
  ],
  declarations: [],
  exports: [ RouterModule ]
})
export class AppRoutingModule { }
