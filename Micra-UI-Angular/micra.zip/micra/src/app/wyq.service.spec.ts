import { TestBed, inject } from '@angular/core/testing';

import { WyqService } from './wyq.service';

describe('WyqService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [WyqService]
    });
  });

  it('should be created', inject([WyqService], (service: WyqService) => {
    expect(service).toBeTruthy();
  }));
});
