export interface ClaimData{
    quUserId: string,
	quClaimOff: string,
	quAtlasYear: string,
	quClaimNumber: string
	quSetup: string,	
	quUnderwritingGroup: string,
	quSourceCode: string,
	quPolicyPrefix: string,
	quPolicyNumber: string,
	termId: string,
	quLargeLossIndicator: string,
	quSuspensionReason: string
	quCompensationClaimIndicator: string
	quTreatyIndicator: string
	quNolCount: number
	quFirstInDate: string
	niRiskId: string
	niCompensationId: string
}