import { Component, OnInit, Renderer2 } from '@angular/core';
import { Location } from '@angular/common';

@Component({
  selector: 'app-worknol',
  templateUrl: './worknol.component.html',
  styleUrls: ['./worknol.component.css']
})
export class WorknolComponent implements OnInit {

  constructor(private renderer: Renderer2, private location: Location) { 
   
  }

  ngOnInit() {
    this.renderer.removeAttribute(document.body, 'class');
    this.renderer.addClass(document.body, 'work-nol-content');
  }

  getBack() {
    this.location.back();
  }
  
}
