import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WorknolComponent } from './worknol.component';

describe('WorknolComponent', () => {
  let component: WorknolComponent;
  let fixture: ComponentFixture<WorknolComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WorknolComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WorknolComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
