import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-worknoltype',
  templateUrl: './worknoltype.component.html',
  styleUrls: ['./worknoltype.component.css']
})
export class WorknoltypeComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }

  getWorkNol(){
    this.router.navigate(['/worknol']);
  }

  
}
