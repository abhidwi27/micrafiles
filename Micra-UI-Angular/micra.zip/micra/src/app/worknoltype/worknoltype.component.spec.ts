import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WorknoltypeComponent } from './worknoltype.component';

describe('WorknoltypeComponent', () => {
  let component: WorknoltypeComponent;
  let fixture: ComponentFixture<WorknoltypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WorknoltypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WorknoltypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
