import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimsetupComponent } from './claimsetup.component';

describe('ClaimsetupComponent', () => {
  let component: ClaimsetupComponent;
  let fixture: ComponentFixture<ClaimsetupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClaimsetupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimsetupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
