import { Component, OnInit, Renderer2 } from '@angular/core';
import { Location } from '@angular/common';

@Component({
  selector: 'app-claimsetup',
  templateUrl: './claimsetup.component.html',
  styleUrls: ['./claimsetup.component.css']
})
export class ClaimsetupComponent implements OnInit {

  constructor(private renderer: Renderer2, private location: Location) { }

  ngOnInit() {
    this.renderer.removeAttribute(document.body, 'class');
    this.renderer.addClass(document.body, 'claimsetup-content');
  }

  getBack() {
    this.location.back();
  }

}
