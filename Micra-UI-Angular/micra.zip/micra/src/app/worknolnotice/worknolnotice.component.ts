import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-worknolnotice',
  templateUrl: './worknolnotice.component.html',
  styleUrls: ['./worknolnotice.component.css']
})
export class WorknolnoticeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
